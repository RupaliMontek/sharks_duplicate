# What? Where? When?

When you are going to report a new issue, include the following information

1. Environment
2. Steps to reproduce
