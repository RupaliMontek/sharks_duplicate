# Contributing

1. Make an issue
2. Create a pull request linked to this issue
